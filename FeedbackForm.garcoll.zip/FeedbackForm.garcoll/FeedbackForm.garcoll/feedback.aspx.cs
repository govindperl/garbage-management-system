﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Data.SqlClient;
using System.Data;
using System.IO;


namespace FeedbackForm.garcoll
{
    public partial class Contact : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnSubmitCom_Click(object sender, EventArgs e)
        {
            try
            {
               // SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\v11.0;AttachDbFilename=E:\garbage collection\FeedbackForm.garcoll\FeedbackForm.garcoll\App_Data\GarbageCollectionInfoFeed.mdf;Integrated Security=True");
                SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\v11.0;AttachDbFilename=D:\FeedbackForm.garcoll\FeedbackForm.garcoll\App_Data\GarbageCollectionInfoFeed.mdf;Integrated Security=True");


                string path = Server.MapPath("Imagesp/");



        if (FileUpload1.HasFile)
        {
            string extension = Path.GetExtension(FileUpload1.FileName);
            if (extension == ".jpg" || extension == ".png" || extension == ".gif")
            {
                FileUpload1.SaveAs(path + FileUpload1.FileName);
                string imgname = "Imagesp/" + FileUpload1.FileName;



                SqlCommand cmd = new SqlCommand("INSERT INTO GarbageDetails(FeedbackerName,AadharNumber,ProblemIn,ComplaintDate,StreetNumber,AddressLine1,AddressLine2,ComplaintDistrict,Stategovt,Pincode,ProblemPic) Values(@FeedbackerName,@AadharNumber,@ProblemIn,@ComplaintDate,@StreetNumber,@AddressLine1,@AddressLine2,@ComplaintDistrict,@Stategovt,@Pincode,@ImageData)", con);


                SqlParameter name = new SqlParameter();
                name.SqlDbType = SqlDbType.NVarChar;
                name.Direction = ParameterDirection.Input;
                name.ParameterName = "@FeedbackerName";
                name.Value = txtFeedbackname.Text;
                cmd.Parameters.Add(name);

                SqlParameter aadhar = new SqlParameter();
                aadhar.SqlDbType = SqlDbType.NVarChar;
                aadhar.Direction = ParameterDirection.Input;
                aadhar.ParameterName = "@AadharNumber";
                aadhar.Value = txtAadharno.Text;
                cmd.Parameters.Add(aadhar);


                SqlParameter prob = new SqlParameter();
                prob.SqlDbType = SqlDbType.NVarChar;
                prob.Direction = ParameterDirection.Input;
                prob.ParameterName = "@ProblemIn";
                prob.Value = ddlProblemin.SelectedItem.ToString();
                cmd.Parameters.Add(prob);


                SqlParameter cdate = new SqlParameter();
                cdate.SqlDbType = SqlDbType.NVarChar;
                cdate.Direction = ParameterDirection.Input;
                cdate.ParameterName = "@ComplaintDate";
                cdate.Value = calenDatecom.SelectedDate.ToShortDateString();
                cmd.Parameters.Add(cdate);


                SqlParameter snum = new SqlParameter();
                snum.SqlDbType = SqlDbType.NVarChar;
                snum.Direction = ParameterDirection.Input;
                snum.ParameterName = "@StreetNumber";
                snum.Value = txtStreetno.Text;
                cmd.Parameters.Add(snum);


                SqlParameter addo = new SqlParameter();
                addo.SqlDbType = SqlDbType.NVarChar;
                addo.Direction = ParameterDirection.Input;
                addo.ParameterName = "@AddressLine1";
                addo.Value = txtAddresslineo.Text;
                cmd.Parameters.Add(addo);


                SqlParameter addtwo = new SqlParameter();
                addtwo.SqlDbType = SqlDbType.NVarChar;
                addtwo.Direction = ParameterDirection.Input;
                addtwo.ParameterName = "@AddressLine2";
                addtwo.Value = txtAddresslinetwo.Text;
                cmd.Parameters.Add(addtwo);


                SqlParameter comdis = new SqlParameter();
                comdis.SqlDbType = SqlDbType.NVarChar;
                comdis.Direction = ParameterDirection.Input;
                comdis.ParameterName = "@ComplaintDistrict";
                comdis.Value = ddlDistrict.SelectedItem.ToString();
                cmd.Parameters.Add(comdis);

                //  SqlParameter district = new SqlParameter();
                //district.SqlDbType = SqlDbType.NVarChar;
                //district.Direction = ParameterDirection.Input;
                //district.ParameterName = "";
                //district.Value=;
                //cmd.Parameters.Add(district);

                SqlParameter stategovt = new SqlParameter();
                stategovt.SqlDbType = SqlDbType.NVarChar;
                stategovt.Direction = ParameterDirection.Input;
                stategovt.ParameterName = "@Stategovt";
                stategovt.Value = ddlState.SelectedItem.ToString();
                cmd.Parameters.Add(stategovt);



                SqlParameter pincode = new SqlParameter();
                pincode.SqlDbType = SqlDbType.NVarChar;
                pincode.Direction = ParameterDirection.Input;
                pincode.ParameterName = "@Pincode";
                pincode.Value = txtPincode.Text;
                cmd.Parameters.Add(pincode);


                SqlParameter picture = new SqlParameter();
                picture.SqlDbType = SqlDbType.NVarChar;
                picture.Direction = ParameterDirection.Input;
                picture.ParameterName = "@ImageData";
                picture.Value = imgname;
                cmd.Parameters.Add(picture);


                con.Open();
                int detailsadded = -1;

                detailsadded = cmd.ExecuteNonQuery();



                if (detailsadded == 1)
                {
                    string alert = string.Format("<script>alert('COMPLAINT REGISTERED')</script>");
                    ClientScript.RegisterStartupScript(this.GetType(), null, alert);
                }
                else
                {
                    string alert = string.Format("<script>alert('COMPLAINT NOT REGISTERED')</script>");
                    ClientScript.RegisterStartupScript(this.GetType(), null, alert);
                }
                con.Close();
            }
        }
            }
            catch (SqlException ex)
            {
                Label10.Text = ex.Message.ToString();
            }
            catch (Exception ex)
            {
                Label10.Text = ex.Message.ToString();
            }

        }

        protected void btnClear_Click(object sender, EventArgs e)
        {
            txtFeedbackname.Text = string.Empty;
            txtAadharno.Text = string.Empty;
            ddlProblemin.ClearSelection();
            calenDatecom.SelectedDates.Clear();
            txtStreetno.Text = string.Empty;
            txtAddresslineo.Text = string.Empty;
            txtAddresslinetwo.Text = string.Empty;
            ddlDistrict.ClearSelection();
            ddlState.ClearSelection();
            txtPincode.Text = string.Empty;
            FileUpload1.Attributes.Clear();
        }
    }
}



       
    
