﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Data;
using System.Data.SqlClient;

namespace FeedbackForm.garcoll
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnADMINlogin_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\v11.0;AttachDbFilename=D:\FeedbackForm.garcoll\FeedbackForm.garcoll\App_Data\GarbageCollectionInfoFeed.mdf;Integrated Security=True");

          

            SqlCommand cmd = new SqlCommand("SELECT * FROM ADMINLOGIN WHERE USERNAME=@UserName and PASSWORD=@Password", con);
          //  cmd.CommandType = CommandType.StoredProcedure;

            SqlParameter empid = new SqlParameter();
            empid.SqlDbType = SqlDbType.NVarChar;
            empid.ParameterName = "@UserName";
            empid.Direction = ParameterDirection.Input;
            empid.Value = txtUSERNAME.Text;
            cmd.Parameters.Add(empid);


            SqlParameter pwd = new SqlParameter();
            pwd.SqlDbType = SqlDbType.VarChar;
            pwd.ParameterName = "@Password";
            pwd.Direction = ParameterDirection.Input;
            pwd.Value = txtPASSWORD.Text;
            cmd.Parameters.Add(pwd);

            con.Open();
            SqlDataReader dr = cmd.ExecuteReader();

            if (dr.HasRows)
            {
                dr.Read();

                Response.Redirect("complaintdetails.aspx");


            }

            con.Close();
        }

        protected void btnCANCEL_Click(object sender, EventArgs e)
        {
            txtUSERNAME.Text = string.Empty;
            txtPASSWORD.Text = string.Empty;


            txtUSERNAME.Focus();
        }
    }
}